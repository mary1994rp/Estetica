package mx.uam.ayd.estetica.negocio;

import mx.uam.ayd.estetica.modelo.Cuenta;
import mx.uam.ayd.estetica.modelo.Empleado;
import mx.uam.ayd.estetica.persistencia.DAOCuentas;
import mx.uam.ayd.estetica.persistencia.DAOEmpleado;

public class ServicioCuenta {
	
	private DAOCuentas daoCuenta;

	public ServicioCuenta(DAOCuentas daoCuenta) {
		this.daoCuenta=daoCuenta;
	}

	public boolean añadirCuenta(String nombre, Empleado empleado, String contraseña) {
		return daoCuenta.añadirCuenta(new Cuenta(nombre, empleado, contraseña));
	}
}
