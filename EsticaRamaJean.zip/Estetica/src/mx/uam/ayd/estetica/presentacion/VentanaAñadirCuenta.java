package mx.uam.ayd.estetica.presentacion;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import mx.uam.ayd.estetica.modelo.Empleado;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaAñadirCuenta extends JFrame {

	private ControlAñadirCuenta controlAñadirCuenta;
	private Empleado[] empleados;
	
	private JPanel contentPane;
	private JTextField JTextFieldNombre;
	private JTextField JTextFieldContraseña;

	public VentanaAñadirCuenta(ControlAñadirCuenta controlAñadirCuenta) {
		this.controlAñadirCuenta=controlAñadirCuenta;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 455, 325);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton JButtonAñadir = new JButton("Añadir");
		JButtonAñadir.setBounds(162, 253, 117, 25);
		contentPane.add(JButtonAñadir);
		
		JTextFieldNombre = new JTextField();
		JTextFieldNombre.setBounds(234, 85, 151, 19);
		contentPane.add(JTextFieldNombre);
		JTextFieldNombre.setColumns(10);
		
		JLabel JLabelNombre = new JLabel("Nombre de cuenta :");
		JLabelNombre.setFont(new Font("Century Schoolbook L", Font.BOLD | Font.ITALIC, 13));
		JLabelNombre.setBounds(56, 89, 138, 15);
		contentPane.add(JLabelNombre);
		
		JLabel JLabelContraseña = new JLabel("Contraseña :");
		JLabelContraseña.setFont(new Font("Century Schoolbook L", Font.BOLD | Font.ITALIC, 13));
		JLabelContraseña.setBounds(78, 136, 102, 15);
		contentPane.add(JLabelContraseña);
		
		JLabel JLabelEncabezado = new JLabel("Crea una nueva Cuenta");
		JLabelEncabezado.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 18));
		JLabelEncabezado.setBounds(99, 12, 242, 40);
		contentPane.add(JLabelEncabezado);
		
		JTextFieldContraseña = new JTextField();
		JTextFieldContraseña.setBounds(234, 132, 151, 19);
		contentPane.add(JTextFieldContraseña);
		JTextFieldContraseña.setColumns(10);
		
		
		JComboBox JcomboBoxEmpleados = new JComboBox();
		JcomboBoxEmpleados.setBounds(231, 188, 102, 24);
		empleados = controlAñadirCuenta.dameEmpleados();
		JcomboBoxEmpleados.setModel(new DefaultComboBoxModel(controlAñadirCuenta.dameEmpleadosNombre(empleados)));
		
		
		contentPane.add(JcomboBoxEmpleados);
		
		JLabel JLabelEmpleado = new JLabel("Empleado");
		JLabelEmpleado.setFont(new Font("Century Schoolbook L", Font.BOLD | Font.ITALIC, 13));
		JLabelEmpleado.setBounds(138, 195, 102, 15);
		contentPane.add(JLabelEmpleado);
		
		JButtonAñadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(JLabelNombre.getText().equals("") || JLabelContraseña.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Termina de llenar los datos");
				}else {
				String nombre = JLabelNombre.getText();
				String nombreEmpleado = JcomboBoxEmpleados.getSelectedItem().toString();
				Empleado empleado = controlAñadirCuenta.buscaEmpleado(nombreEmpleado, empleados);
				String contraseña = JLabelContraseña.getText();
				if(controlAñadirCuenta.añadirCuenta(nombre, empleado, contraseña)) {
					JOptionPane.showMessageDialog(null, "Se ha añadido correctamente");
				}
			}
			}
		});
	}
}
